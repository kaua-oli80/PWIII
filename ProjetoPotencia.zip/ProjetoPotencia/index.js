import express from 'express'
const app = express()

app.use(
    express.urlencoded({
        extended:true
    })
);

app.use(express.json())

const listaBasica = [
  {questao: 1,
    descricao: '3 ^ 2',
    resolucao : {
        linha1: '3 ^ 2 = 3 * 3',
        linha2: '9'
    }
  },

  { questao: 2,
    descricao: '3 ^ 2 * 3 ^ 2',
    resolucao : {
        linha1: '3 ^ 2 = 3 * 3',
        linha2: '9',
        linha3: '3 ^ 2 = 3 * 3',
        linha4: '9',
        linha5: '9 * 9',
        linha6: '81'
    } ,
  },

  {questao: 3,
    descricao: '3 ^ 2 (4/2)',
    resolucao : {
        linha1: '3 ^ 2 = 3 * 3 = 9',
        linha2: '9',
        linha3: '4 / 2',
        linha4: '2',
        linha5: '9 * 2',
        linha6: '18',
    } ,
  },

  {questao: 4,
    descricao: '4 * 3',
    resolucao : {
        linha1: '4 * 3 = 4 + 4 + 4',
        linha2: '12'
    } ,
  },

  {questao: 5,
    descricao: '90 - 5',
    resolucao : {
        linha1: '90 - 5 = 85',
        linha2: '85'
    }
  },

  {questao: 6,
    descricao: '200 / 4',
    resolucao : {
        linha1: '200 / 4 = 50',
        linha2: '50'
    }
  },

  {questao: 7,
    descricao: '1500 + 3500',
    resolucao : {
        linha1: '1500 + 3500 = 5000',
        linha2: '5000'
    }
  },

  {questao: 8,
    descricao: '40 * 3 - 10',
    resolucao : {
        linha1: '40 * 3 = 120',
        linha2: '120 - 10 = 110'
    } ,
  },

  {questao: 9,
    descricao: '12 * 50',
    resolucao : {
        linha1: '12 * 50 = 600',
        linha2: '600'
    } ,
  },

  {questao: 10,
    descricao: '80 - 150',
    resolucao : {
        linha1: '80 - 150 = -70',
        linha2: '-70',
    } ,
  }
]

const listaVestibular = [
  {questao: 1,
    descricao: 'Simplifique a expressão: 3^2 * 3^3',
    resolucao : {
        linha1: '3^2+3 = 3^5',
        linha2: '3^5 = 243',
        linha3: '243'
    },
  },

  {questao: 2,
    descricao: 'Calcule o valor de: (2^3)^2',
    resolucao : {
        linha1: '2^(3*2) = 2^6',
        linha2: '2^6',
        linha3: '64'
    } ,
  },

  {questao: 3,
    descricao: 'Determine o resultado da expressão: 6^3 ÷ 6^2',
    resolucao : {
        linha1: '6^(3-2)',
        linha2: '6^1',
        linha3: '6'
    } ,
  },

  {questao: 4,
    descricao: 'Resolva: 3^3 * 2^2',
    resolucao : {
        linha1: '27 * 4',
        linha2: '108',
    } ,
  },

  {questao: 5,
    descricao: 'Simplifique: (2^4)^2 ÷ 2^3',
    resolucao : {
        linha1: '(2^4)^2 = 2^8',
        linha2: '2^8 ÷ 2^3 = 2^(8-3)',
        linha3: '2^5 = 32'
    } ,
  }
]

function buscarPorQuestaoBasica (questao) {
  return listaBasica.filter(exercicio => exercicio.questao == questao)
}

function buscarPorQuestaoVestibular (questao) {
  return listaVestibular.filter(exercicio => exercicio.questao.toString().includes(questao))
}

//Query
app.get('/exerc/query/basica', (req, res) => {
  const { questao } = req.query;
  res.send(buscarPorQuestaoBasica(questao));
})

app.get('/exerc/query/vestibular', (req, res) => {
  const { questao } = req.query;
  res.send(buscarPorQuestaoVestibular(questao));
})

//Body
app.post('/exerc/body/basica', (req, res) => {
  const { questao } = req.body;
  res.send(buscarPorQuestaoBasica(questao));
})

app.post('/exerc/body/vestibular', (req, res) => {
  const { questao } = req.body;
  res.send(buscarPorQuestaoVestibular(questao));
})

app.get('/express', (req, res) => {
res.send(`
<!DOCTYPE html>
<html>
<head>
<title>Exercícios de Matemática</title>

<style>

body{
    font-family: Arial, Helvetica, sans-serif;
    background: linear-gradient(135deg,#4facfe,#00f2fe);
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

.container{
    background:white;
    padding:30px;
    border-radius:10px;
    box-shadow:0 0 15px rgba(0,0,0,0.2);
    text-align:center;
}

h1{
    color:#333;
}

input{
    padding:10px;
    margin:10px;
    width:200px;
    border-radius:5px;
    border:1px solid #ccc;
}

button{
    padding:10px 20px;
    border:none;
    border-radius:5px;
    background:#4facfe;
    color:white;
    cursor:pointer;
    font-size:16px;
}

button:hover{
    background:#0077ff;
}

#resultado{
    margin-top:20px;
    text-align:left;
}

</style>
</head>

<body>

<div class="container">

<h1>Buscar Exercício</h1>

<input id="questao" placeholder="Digite o número da questão">

<br>

<button onclick="buscarBasica()">Buscar Básica</button>
<button onclick="buscarVestibular()">Buscar Vestibular</button>

<div id="resultado"></div>

</div>

<script>

function buscarBasica(){

const questao = document.getElementById("questao").value

fetch('/exerc/query/basica?questao=' + questao)
.then(res => res.json())
.then(dados => mostrar(dados))

}

function buscarVestibular(){

const questao = document.getElementById("questao").value

fetch('/exerc/query/vestibular?questao=' + questao)
.then(res => res.json())
.then(dados => mostrar(dados))

}

function mostrar(dados){

let html = ""

dados.forEach(ex => {

html += "<h3>Questão: " + ex.descricao + "</h3>"

for(let linha in ex.resolucao){
html += "<p>" + ex.resolucao[linha] + "</p>"
}

})

document.getElementById("resultado").innerHTML = html

}

</script>

</body>
</html>
`)
})

app.listen(3000, ()=> {
  console.log("Rodando na porta 3000")
})